"""
test_pipeline.py
=================
Unit tests covering each preprocessing stage described in the strategy
document. Run with: pytest tests/ -v
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from validate import validate_schema
from clean import (
    handle_missing_values,
    detect_outliers_iqr,
    detect_outliers_zscore,
    detect_and_treat_outliers,
    clean_data,
)
from transform import encode_categorical_features, transform_features, split


@pytest.fixture
def sample_df():
    return pd.DataFrame({
        "age": [25, 30, 29, np.nan, 150, 31, 28],
        "city": [" NYC", "LA ", "NYC", "SF", "LA", "nyc", None],
        "score": [10.1, 10.5, 9.9, 10.2, 10.0, 10.3, 500.0],
    })


def test_validate_schema_detects_missing_columns(sample_df):
    report = validate_schema(sample_df, expected_columns=["age", "city", "income"])
    assert report.has_critical_errors
    assert "income" in report.errors[0]


def test_validate_schema_missing_summary(sample_df):
    report = validate_schema(sample_df)
    assert report.missing_summary["age"] > 0


def test_handle_missing_values_fills_all_na(sample_df):
    df = handle_missing_values(sample_df)
    assert df.isnull().sum().sum() == 0


def test_detect_outliers_iqr_flags_extreme_value():
    s = pd.Series([10, 11, 9, 10, 12, 500])
    mask = detect_outliers_iqr(s)
    assert mask.iloc[-1]  # 500 should be flagged
    assert not mask.iloc[0]


def test_detect_outliers_zscore_flags_extreme_value():
    s = pd.Series([10, 11, 9, 10, 12, 500])
    mask = detect_outliers_zscore(s, threshold=2.0)
    assert mask.iloc[-1]


def test_detect_and_treat_outliers_capping_reduces_max():
    df = pd.DataFrame({"x": [1, 2, 3, 4, 1000]})
    treated = detect_and_treat_outliers(df, columns=["x"], treatment="cap")
    assert treated["x"].max() < 1000


def test_clean_data_deduplicates_and_trims_text():
    df = pd.DataFrame({"city": [" NYC", "NYC ", "LA"], "val": [1, 1, 2]})
    cleaned = clean_data(df)
    assert len(cleaned) == 2  # exact dupes (after trim) removed


def test_encode_categorical_features_creates_dummies():
    df = pd.DataFrame({"cat": ["a", "b", "a"], "num": [1, 2, 3]})
    encoded = encode_categorical_features(df, ["cat"])
    assert "cat_b" in encoded.columns


def test_split_respects_test_size():
    df = pd.DataFrame({"x": range(100), "y": [0, 1] * 50})
    train_df, val_df = split(df, test_size=0.2)
    assert len(val_df) == 20
    assert len(train_df) == 80


def test_full_transform_pipeline_produces_numeric_frame(sample_df):
    df = handle_missing_values(sample_df)
    df = detect_and_treat_outliers(df)
    df = clean_data(df)
    transformed = transform_features(df)
    assert transformed.isnull().sum().sum() == 0
    assert transformed.shape[0] == df.shape[0]
