"""
pipeline.py
===========
Orchestrates the full data acquisition & preprocessing pipeline, matching
Appendix A of the strategy document.

Usage:
    python src/pipeline.py --source-config config/source.yaml
"""
from __future__ import annotations

import argparse
import json
import logging
from pathlib import Path

import yaml

from extract import extract_data
from validate import validate_schema
from clean import handle_missing_values, detect_and_treat_outliers, clean_data
from transform import transform_features, split

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

PROCESSED_DIR = Path("data/processed")


class PipelineError(Exception):
    """Raised when a validation gate fails critically."""


def run_pipeline(source_config: dict, target_col: str | None = None):
    # 1. Extract (Section 3)
    raw_df = extract_data(source_config)

    # 2. Validate (Section 4.1) — quality gate
    report = validate_schema(raw_df, expected_columns=source_config.get("expected_columns"))
    if report.has_critical_errors:
        raise PipelineError(f"Validation failed: {report.errors}")

    # 3. Missing values (Section 4.2)
    df = handle_missing_values(raw_df)

    # 4. Outliers (Section 4.3)
    df = detect_and_treat_outliers(df)

    # 5. Cleaning (Section 5)
    df = clean_data(df)

    # 6. Re-validate after cleaning (quality gate)
    post_report = validate_schema(df)
    logger.info("Post-clean missingness: %s", post_report.missing_summary)

    # 7. Transform (Section 6)
    df = transform_features(df)
    train_df, val_df = split(df, target_col=target_col)

    # 8. Persist
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    df.to_parquet(PROCESSED_DIR / "clean_dataset.parquet", index=False)
    logger.info("Saved processed dataset: %d rows, %d columns", *df.shape)

    return train_df, val_df


def main():
    parser = argparse.ArgumentParser(description="Run the data preprocessing pipeline.")
    parser.add_argument("--source-config", required=True, help="Path to a YAML/JSON source config file")
    parser.add_argument("--target-col", default=None, help="Target column for stratified split")
    args = parser.parse_args()

    config_path = Path(args.source_config)
    if config_path.suffix in (".yaml", ".yml"):
        source_config = yaml.safe_load(config_path.read_text())
    else:
        source_config = json.loads(config_path.read_text())

    run_pipeline(source_config, target_col=args.target_col)


if __name__ == "__main__":
    main()
