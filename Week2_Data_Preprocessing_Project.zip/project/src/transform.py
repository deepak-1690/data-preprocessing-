"""
transform.py
============
Feature scaling, encoding, and engineering (Section 6 of the strategy
document). Transformations are fit on training data only to avoid
data leakage.
"""
from __future__ import annotations

import logging

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder

logger = logging.getLogger(__name__)


def scale_numeric_features(
    df: pd.DataFrame, columns: list[str], scaler: StandardScaler | None = None
) -> tuple[pd.DataFrame, StandardScaler]:
    """Standardize numeric columns; returns the fitted scaler for reuse on new data."""
    df = df.copy()
    scaler = scaler or StandardScaler()
    df[columns] = scaler.fit_transform(df[columns]) if not hasattr(scaler, "mean_") else scaler.transform(df[columns])
    return df, scaler


def encode_categorical_features(df: pd.DataFrame, columns: list[str]) -> pd.DataFrame:
    """One-hot encode categorical columns."""
    return pd.get_dummies(df, columns=columns, drop_first=True)


def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Example derived-feature logic. Extend with project-specific ratios,
    date-part extraction, or aggregates as needed (Section 6).
    """
    df = df.copy()
    for col in df.select_dtypes(include=["datetime64[ns]"]).columns:
        df[f"{col}_year"] = df[col].dt.year
        df[f"{col}_month"] = df[col].dt.month
        df[f"{col}_dayofweek"] = df[col].dt.dayofweek
    return df


def transform_features(
    df: pd.DataFrame,
    numeric_columns: list[str] | None = None,
    categorical_columns: list[str] | None = None,
) -> pd.DataFrame:
    """Full transformation pass combining engineering, scaling, and encoding."""
    df = engineer_features(df)

    numeric_columns = numeric_columns or df.select_dtypes(include=[np.number]).columns.tolist()
    categorical_columns = categorical_columns or df.select_dtypes(include=["object"]).columns.tolist()

    if numeric_columns:
        df, _ = scale_numeric_features(df, numeric_columns)
    if categorical_columns:
        df = encode_categorical_features(df, categorical_columns)

    logger.info("Transformation complete: %d columns in final feature set", df.shape[1])
    return df


def split(df: pd.DataFrame, target_col: str | None = None, test_size: float = 0.2, stratify: bool = False):
    """Train/validation split performed before any leakage-prone fitting."""
    stratify_col = df[target_col] if (stratify and target_col) else None
    train_df, val_df = train_test_split(df, test_size=test_size, stratify=stratify_col, random_state=42)
    return train_df, val_df
