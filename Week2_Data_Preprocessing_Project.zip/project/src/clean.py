"""
clean.py
========
Missing-value handling, outlier detection, and general data cleaning
(Sections 4.2, 4.3, and 5 of the strategy document).
"""
from __future__ import annotations

import logging

import numpy as np
import pandas as pd
from sklearn.impute import KNNImputer, SimpleImputer

logger = logging.getLogger(__name__)


def handle_missing_values(
    df: pd.DataFrame,
    numeric_strategy: str = "median",
    categorical_strategy: str = "most_frequent",
    knn_neighbors: int | None = None,
) -> pd.DataFrame:
    """
    Impute missing values column-type-aware, per Section 4.2's decision table.
    Set knn_neighbors to use KNN imputation for numeric columns instead of
    simple mean/median imputation.
    """
    df = df.copy()
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    categorical_cols = df.select_dtypes(exclude=[np.number]).columns

    if len(numeric_cols) > 0:
        if knn_neighbors:
            imputer = KNNImputer(n_neighbors=knn_neighbors)
            df[numeric_cols] = imputer.fit_transform(df[numeric_cols])
        else:
            imputer = SimpleImputer(strategy=numeric_strategy)
            df[numeric_cols] = imputer.fit_transform(df[numeric_cols])

    if len(categorical_cols) > 0:
        cat_imputer = SimpleImputer(strategy=categorical_strategy)
        df[categorical_cols] = cat_imputer.fit_transform(df[categorical_cols])

    logger.info("Missing values imputed (numeric=%s, categorical=%s)", numeric_strategy, categorical_strategy)
    return df


def detect_outliers_iqr(series: pd.Series, k: float = 1.5) -> pd.Series:
    """Flag outliers using the IQR fencing method. Returns a boolean mask."""
    q1, q3 = series.quantile(0.25), series.quantile(0.75)
    iqr = q3 - q1
    lower, upper = q1 - k * iqr, q3 + k * iqr
    return (series < lower) | (series > upper)


def detect_outliers_zscore(series: pd.Series, threshold: float = 3.0) -> pd.Series:
    """Flag outliers using the Z-score method. Returns a boolean mask."""
    mean, std = series.mean(), series.std(ddof=0)
    if std == 0:
        return pd.Series(False, index=series.index)
    z = (series - mean) / std
    return z.abs() > threshold


def detect_and_treat_outliers(
    df: pd.DataFrame,
    columns: list[str] | None = None,
    method: str = "iqr",
    treatment: str = "cap",
) -> pd.DataFrame:
    """
    Detect outliers per numeric column and treat them (Section 4.3).
    treatment: 'cap' (winsorize to the fence), 'flag' (add an indicator
    column, no value change), or 'remove' (drop flagged rows).
    """
    df = df.copy()
    columns = columns or df.select_dtypes(include=[np.number]).columns.tolist()

    for col in columns:
        mask = (
            detect_outliers_iqr(df[col]) if method == "iqr" else detect_outliers_zscore(df[col])
        )
        n_flagged = int(mask.sum())
        if n_flagged == 0:
            continue

        logger.info("Column '%s': %d outliers flagged via %s", col, n_flagged, method)

        if treatment == "flag":
            df[f"{col}_is_outlier"] = mask
        elif treatment == "cap":
            q1, q3 = df[col].quantile(0.25), df[col].quantile(0.75)
            iqr = q3 - q1
            lower, upper = q1 - 1.5 * iqr, q3 + 1.5 * iqr
            df[col] = df[col].clip(lower=lower, upper=upper)
        elif treatment == "remove":
            df = df.loc[~mask]

    return df


def clean_data(df: pd.DataFrame, dedupe_subset: list[str] | None = None) -> pd.DataFrame:
    """
    General cleaning pass (Section 5): type coercion, text normalization,
    and de-duplication.
    """
    df = df.copy()

    # Text normalization for object/string columns
    for col in df.select_dtypes(include=["object"]).columns:
        df[col] = df[col].astype(str).str.strip()

    # De-duplication
    before = len(df)
    df = df.drop_duplicates(subset=dedupe_subset)
    logger.info("De-duplication removed %d rows", before - len(df))

    return df.reset_index(drop=True)
